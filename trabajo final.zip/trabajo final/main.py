from complejidad import predecir_complejidad
from ordenamiento import optimizar_ordenamiento
from estructuras import resolver_estructuras

def menu():
    while True:
        print("\n=== Proyecto Final ADA I ===")
        print("1. Predecir Complejidad Algorítmica")
        print("2. Optimizar Ordenamiento de Listas")
        print("3. Simulación de Estructuras de Datos")
        print("4. Salir")

        opcion = input("Selecciona una opción (1-4): ")

        if opcion == '1':
            predecir_complejidad()
        elif opcion == '2':
            optimizar_ordenamiento()
        elif opcion == '3':
            resolver_estructuras()
        elif opcion == '4':
            print("¡Gracias por usar el sistema!")
            break
        else:
            print("Opción no válida. Intenta de nuevo.")

if __name__ == "__main__":
    menu()
