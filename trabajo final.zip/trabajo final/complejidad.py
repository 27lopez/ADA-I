import os
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense
from tensorflow.keras.utils import to_categorical
import joblib

# Datos de ejemplo (simulados para entrenar)
ejemplos = [
    "for i in range(n): for j in range(n): print(i*j)",  # O(n^2)
    "for i in range(n): print(i)",                       # O(n)
    "print('Hola mundo')",                               # O(1)
]

etiquetas = [0, 1, 2]  # 0 = O(n^2), 1 = O(n), 2 = O(1)

# Archivos del modelo
vectorizer_path = "vectorizer.pkl"
modelo_path = "complejidad_model.h5"

def entrenar_modelo():
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(ejemplos).toarray()
    y = to_categorical(etiquetas)

    model = Sequential([
        Dense(64, activation='relu', input_shape=(X.shape[1],)),
        Dense(64, activation='relu'),
        Dense(3, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    model.fit(X, y, epochs=10, verbose=0)

    model.save(modelo_path)
    joblib.dump(vectorizer, vectorizer_path)
    print(" Modelo entrenado y guardado.")

def predecir_complejidad():
    if not os.path.exists(modelo_path) or not os.path.exists(vectorizer_path):
        print(" Entrenando modelo por primera vez...")
        entrenar_modelo()

    model = load_model(modelo_path)
    vectorizer = joblib.load(vectorizer_path)

    print("\n[ Predicción de Complejidad]")
    codigo = input("Escribe una línea de código Python: ")

    X = vectorizer.transform([codigo]).toarray()
    pred = model.predict(X)[0]
    clases = ['O(n^2)', 'O(n)', 'O(1)']

    print("\n--- Resultados ---")
    print(f"Big-O : {clases[np.argmax(pred)]}")
    print(f"Ω     : {clases[np.argmax(pred)]}")
    print(f"ϴ     : {clases[np.argmax(pred)]}")
