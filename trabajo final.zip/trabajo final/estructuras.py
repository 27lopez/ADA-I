from collections import deque

def resolver_estructuras():
    print("\n[Estructuras de Datos]")
    print("1. Pila")
    print("2. Cola")
    opcion = input("Selecciona una opción (1-2): ")

    if opcion == '1':
        simulacion_pila_usuario()
    elif opcion == '2':
        simulacion_cola_usuario()
    else:
        print("Opción inválida.")

# -----------------------------
# PILA (entrada del usuario)
# -----------------------------

def simulacion_pila_usuario():
    print("\n[PILA]")
    pila = []
    while True:
        print(f"\nPila actual: {pila}")
        print("1. push(x)")
        print("2. pop()")
        print("3. Salir")
        opcion = input("Elige una operación: ")
        if opcion == '1':
            x = input("Valor a push: ")
            pila.append(x)
        elif opcion == '2':
            if pila:
                print(f"pop() -> {pila.pop()}")
            else:
                print("La pila está vacía.")
        elif opcion == '3':
            break
        else:
            print("Opción inválida.")

# -----------------------------
# COLA (entrada del usuario)
# -----------------------------

def simulacion_cola_usuario():
    print("\n[COLA]")
    cola = deque()
    while True:
        print(f"\nCola actual: {list(cola)}")
        print("1. enqueue(x)")
        print("2. dequeue()")
        print("3. Salir")
        opcion = input("Elige una operación: ")
        if opcion == '1':
            x = input("Valor a enqueue: ")
            cola.append(x)
        elif opcion == '2':
            if cola:
                print(f"dequeue() -> {cola.popleft()}")
            else:
                print("La cola está vacía.")
        elif opcion == '3':
            break
        else:
            print("Opción inválida.")
