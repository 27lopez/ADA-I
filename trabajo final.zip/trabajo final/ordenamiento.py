import numpy as np
import random

def optimizar_ordenamiento():
    print("\n[ Optimización de Ordenamiento de Listas]")
    print("1. Simulación Supervisada (Bubble Sort con LSTM)")
    print("2. Simulación RL (Agente con recompensas)")
    opcion = input("Selecciona el modo (1-2): ")

    if opcion == '1':
        modo_lstm()
    elif opcion == '2':
        modo_rl()
    else:
        print("Opción inválida.")

# Simulación de LSTM aprendiendo Bubble Sort (sin entrenamiento real aún)
def modo_lstm():
    print("\n[MODO LSTM] Simulación de pasos Bubble Sort aprendidos")
    lista = input("Introduce una lista de números separados por coma: ")
    try:
        datos = list(map(int, lista.split(",")))
        pasos_bubble_sort(datos.copy())
    except:
        print("Entrada inválida.")

def pasos_bubble_sort(arr):
    print(f"Lista inicial: {arr}")
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            print(f"Comparando {arr[j]} y {arr[j+1]}")
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                print(f" --> Intercambio: {arr}")
            else:
                print(" --> No se intercambia")
    print(f"Lista ordenada: {arr}")

# Simulación de agente RL básico con recompensas
def modo_rl():
    print("\n[MODO RL] Agente básico para ordenar con recompensas")
    lista = input("Introduce una lista de números separados por coma: ")
    try:
        datos = list(map(int, lista.split(",")))
        reward = entorno_agente_rl(datos.copy())
        print(f"Recompensa total: {reward}")
    except:
        print("Entrada inválida.")

def entorno_agente_rl(arr):
    print(f"Estado inicial: {arr}")
    total_reward = 0
    n = len(arr)
    for _ in range(n * n):  # máximo n² acciones
        idx = random.randint(0, n - 2)
        print(f"Agente intenta swap entre {arr[idx]} y {arr[idx+1]}")
        total_reward -= 1  # penalización por comparar
        if arr[idx] > arr[idx + 1]:
            arr[idx], arr[idx + 1] = arr[idx + 1], arr[idx]
            print(f" -> swap hecho: {arr}")
        else:
            print(" -> no se hace swap")

        if arr == sorted(arr):
            total_reward += 100
            print(" Lista ordenada")
            break
    return total_reward
